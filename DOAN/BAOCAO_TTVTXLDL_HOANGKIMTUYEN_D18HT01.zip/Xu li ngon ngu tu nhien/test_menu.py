print(""" 
    1.Lấy link tuyển dụng
    2.Thu thập thông tin tuyển dụng(Tiêu đề, mô tả, vị trí tuyển dụng, . . .)
    3.Thu thập thông tin ứng viên(Tên, bằng cấp, địa chỉ, . . )
    4.Loại bỏ Stopword
    5.Thống kê ngành nghề tuyển dụng
    6.Thống kê địa điểm tuyển dụng
    7.Thoát 
    """)


print("""
        1. tieude
        2. mota
        """)