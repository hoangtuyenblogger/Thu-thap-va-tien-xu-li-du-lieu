import nltk

from nltk.book import *


