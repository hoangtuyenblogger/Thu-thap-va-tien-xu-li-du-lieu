from nltk.tokenize import *
text = "Hoàng Kim Tuyến sống ở Thủ Dầu Một. Tuyến yêu Hoa rất nhiều"

print(sent_tokenize(text))
print(word_tokenize(text))

b = tokenzier_content()