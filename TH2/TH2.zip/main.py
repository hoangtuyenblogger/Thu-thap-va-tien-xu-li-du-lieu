from selenium import webdriver
from time import sleep
from selenium.webdriver.common.keys import Keys
import random

time_sleep = random.randint(2,8)
# 1. Khai bao bien browser
browser = webdriver.Chrome(executable_path="chromedriver.exe")

# 2. Mở thử một trang web
browser.get("http://youtube.com")

login_button = browser.find_element_by_xpath("/html/body/ytd-app/div/div/ytd-masthead/div[3]/div[3]/div[2]/ytd-button-renderer")
login_button.click()
sleep(random.randint(5,10))

